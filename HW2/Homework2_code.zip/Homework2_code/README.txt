Type the following command line in the terminal:

python Problem1.py args_1 args_2 

Here,
args_1: dir of .uai file
args_2: dir of .uai.evid file

For example:

python Problem1.py ./homework2_files/1.uai ./homework2_files/1.uai.evid

Then, the program will print out the corresponding Elimination order and Partition function.