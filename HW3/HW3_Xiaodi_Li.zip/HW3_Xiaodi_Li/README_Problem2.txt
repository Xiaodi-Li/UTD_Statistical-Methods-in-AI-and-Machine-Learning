Type the following command line in the terminal:

python Problem1.py args_1 args_2 args_3 args_4

Here,
args_1: dir of .uai file
args_2: dir of .uai.evid file
args_3: w
args_4: N

For example:

python Part6_Problem2.py ./hw3-files/3.uai ./hw3-files/3.uai.evid 3 500

Then, the program will print out the corresponding Elimination order and Partition function.